/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package christmasgui;

/**
 *
 * @author Yi Wu
 */
public class Christmas {
    private String name;
    private String url;
    private String idea;
    
    public void setName(String name){
        this.name = name;
    }
    public void setUrl(String url){
        this.url = url;
    }
    public void setIdea(String idea){
        this.idea = idea;
    }
    public String getName(){
        return name;
    }
    public String getUrl(){
        return url;
    }
    public String getIdea(){
        return idea;
    }
}
